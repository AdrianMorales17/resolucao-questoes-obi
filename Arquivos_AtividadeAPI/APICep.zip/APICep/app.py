from flask import Flask, render_template, request, abort
import requests, json


app = Flask(__name__)

CEP_URL = "http://www.viacep.com.br/ws/{}/json"

@app.route("/", methods=['GET', 'POST'])
def endereco():
    if request.method == 'POST':
        cep = request.form['cep']
        try:
            resposta = requests.get(CEP_URL.format(cep))
            resposta.raise_for_status()
            dados = resposta.json()
            if 'erro' in dados:
                abort(404, description="CEP inválido! Tente novamente!")
            endereco = {
                "logradouro": dados.get("logradouro", ""),
                "bairro": dados.get("bairro", ""),
                "localidade": dados.get("localidade", ""),
                "uf": dados.get("uf", ""),
                "cep": dados.get("cep", ""),
                "complemento": dados.get("complemento", "")
            }
            return render_template("index.html", endereco=endereco)
        except requests.exceptions.HTTPError as e:
            abort(resposta.status_code, description=str(e))
        except Exception as e:
            abort(500, description="Erro interno do servidor. Erro: " + str(e))
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
